#include<vector>

int roots_count(float a, float b, float c);
std::vector<float> roots(float a, float b, float c);
bool has_roots(float a, float b, float c);
