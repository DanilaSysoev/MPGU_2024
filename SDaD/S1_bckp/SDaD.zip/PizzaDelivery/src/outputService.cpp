#include <vector>
#include <iostream>

void printMessage(const std::string& message)
{
    std::cout << message << '\n';
}