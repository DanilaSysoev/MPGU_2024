#pragma once
#ifndef INPUT_SERVICE_HPP
#define INPUT_SERVICE_HPP

#include <string>

int getInt();
std::string getLine();

#endif