#pragma once
#ifndef CONSOLE_UI_HPP
#define CONSOLE_UI_HPP

void printMainMenu();

#endif