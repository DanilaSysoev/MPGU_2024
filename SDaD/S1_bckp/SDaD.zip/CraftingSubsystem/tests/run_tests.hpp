#include "Item_Tests.hpp"
#include "ItemsCatalog_Tests.hpp"
#include "Recipe_Tests.hpp"