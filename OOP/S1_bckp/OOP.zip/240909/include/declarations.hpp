int sum(int a, int b);
int sum(int arr[], int size);
