#include "SecondLevelTwo.hpp"

SecondLevelTwo::SecondLevelTwo(int iField, float dField)
    : TopLevel(iField), dField(dField)
{}
