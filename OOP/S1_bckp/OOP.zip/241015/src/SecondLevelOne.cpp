#include "SecondLevelOne.hpp"

SecondLevelOne::SecondLevelOne(int iField, float fField)
    : TopLevel(iField), fField(fField)
{}
