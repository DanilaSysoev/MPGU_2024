#include <iostream>
#include "main.hpp"

using namespace std;

int main() {
    {
        // Parent p(10, 5.5f);
        // Child c(4, 2.2f, 3.5);
        // SecondParent sp(30);
        // DoubleChild dc(12, 4, 3.7f, 5.4);

        ThirdLevel third(1, 2.2f, 3.3, true);

        // cout << p << endl;
        // cout << c << endl;
        // cout << sp << endl;
        // cout << dc << endl;
    }

    return 0;
}
