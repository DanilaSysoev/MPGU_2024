#include <iostream>
#include <cstdint>
#include <limits>

using namespace std;

int main()
{
    int a[1000] = {0};

    return 0;
}
