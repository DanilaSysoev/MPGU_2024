#pragma once

#include <vector>

float count_mean_even(const std::vector<int>& data);
