#include "Student.hpp"

Student::Student(const std::string& name, int age, int year, float mean_points)
    : name(name), age(age), year(year), mean_points(mean_points)
{}
