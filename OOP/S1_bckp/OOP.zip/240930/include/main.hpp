#include "StaticDemo.hpp"
#include "CreateDestroyWriter.hpp"