#pragma once
#ifndef CREATEDESTROYWRITER_HPP
#define CREATEDESTROYWRITER_HPP

class CreateDestroyWriter {
public:
    CreateDestroyWriter();
    ~CreateDestroyWriter();
};

#endif