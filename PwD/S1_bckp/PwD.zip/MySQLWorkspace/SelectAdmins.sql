SELECT (EntityName) FROM Entity
WHERE EntityGroupId = 1;