SELECT * FROM Entity;
