CREATE TABLE IF NOT EXISTS EntityGroup (
    EntityGroupId INT AUTO_INCREMENT PRIMARY KEY,
    EntityGroupName CHAR(64) NOT NULL,
    EntityGroupDescription TEXT NOT NULL
);
