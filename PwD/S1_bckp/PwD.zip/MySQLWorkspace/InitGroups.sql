INSERT INTO EntityGroup (EntityGroupName, EntityGroupDescription)
                 VALUES ('Administrators', 'Administrators of the system');

INSERT INTO EntityGroup (EntityGroupName, EntityGroupDescription)
                 VALUES ('Users', 'Users of the system');

INSERT INTO EntityGroup (EntityGroupName, EntityGroupDescription)
                 VALUES ('Guests', 'Guests of the system');
