INSERT INTO Entity (EntityName, EntityGroupId)
            VALUES ('Admin', 1);

INSERT INTO Entity (EntityName, EntityGroupId)
            VALUES ('Alexey', 2);
INSERT INTO Entity (EntityName, EntityGroupId)
            VALUES ('Ivan', 2);
INSERT INTO Entity (EntityName, EntityGroupId)
            VALUES ('Tatyana', 2);

INSERT INTO Entity (EntityName, EntityGroupId)
            VALUES ('G1', 3);
INSERT INTO Entity (EntityName, EntityGroupId)
            VALUES ('G2', 3);
