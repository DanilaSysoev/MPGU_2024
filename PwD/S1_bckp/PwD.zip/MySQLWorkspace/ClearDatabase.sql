DROP TABLE Entity;
DROP TABLE EntityGroup;
