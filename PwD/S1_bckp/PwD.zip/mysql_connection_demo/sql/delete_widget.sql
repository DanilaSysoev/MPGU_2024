DELETE FROM Widget
WHERE id = %s;