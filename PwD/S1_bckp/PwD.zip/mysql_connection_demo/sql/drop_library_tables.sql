DROP TABLE Library_Book;
DROP TABLE Library;
DROP TABLE Book;
