INSERT INTO Widget (Data) VALUES (%s);
