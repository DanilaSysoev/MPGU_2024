DROP INDEX Table_1_name_index ON Table_1_Indexed;
DROP TABLE Table_1;
DROP TABLE Table_1_Indexed;
