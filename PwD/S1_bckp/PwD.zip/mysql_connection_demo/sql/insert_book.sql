INSERT INTO Book (name, author, year)
          VALUES (%s, %s, %s);
