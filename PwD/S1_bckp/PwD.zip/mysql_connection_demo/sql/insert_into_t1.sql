INSERT INTO Table_1 (id, data)
            VALUES (%s, %s);
