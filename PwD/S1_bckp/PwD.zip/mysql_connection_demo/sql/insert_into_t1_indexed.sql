INSERT INTO Table_1_Indexed (id, data)
            VALUES (%s, %s);
