REPLACE Library_Book (book_id, library_id)
              VALUES (%s, %s);
