INSERT INTO Library (name, address)
             VALUES (%s, %s);
